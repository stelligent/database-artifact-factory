class ConfigException(Exception):
    pass